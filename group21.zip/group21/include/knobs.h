#define BLK_OFFSET 6

#define L2_SETS 1024
#define L2_WAYS 8

#define L3_SETS 2048
#define L3_WAYS 16
